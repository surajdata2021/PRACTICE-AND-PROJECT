USE [AdventureWorksDW2012]
GO


/*** 1. Use the inbuilt functions and find the minimum, maximum and average amount from the orders
table ****/
SELECT min(amount), max(amount), avg(amount)
  FROM [dbo].[Orders]
GO


/******2. Create a user-defined function, which will multiply the given number with 10  ****/

/****** Object:  UserDefinedFunction [dbo].[udfTenMultiplyAny]    Script Date: 10/18/2022 11:36:50 PM ******/
DROP FUNCTION [dbo].[udfTenMultiplyAny]
GO

/****** Object:  UserDefinedFunction [dbo].[udfTenMultiplyAny]    Script Date: 10/18/2022 11:36:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ******************************************************
-- Create User Defined Functions
-- ******************************************************
CREATE FUNCTION [dbo].[udfTenMultiplyAny] (@num money)
RETURNS money
AS 
BEGIN
	RETURN 10*@num;
END;

GO

SELECT order_id, [dbo].[udfTenMultiplyAny](amount) as TenTimesAmt
  FROM [dbo].[Orders]
GO



/******3. Use the case statement to check if 100 is less than 200, greater than 200 or equal to 200 and
print the corresponding value  *****/

select order_id, 
	case when amount <= 200 then 'Amount too less'
	     when amount > 200 then 'Amount subjected to IRS'
	end
FROM [dbo].[Orders]
GO