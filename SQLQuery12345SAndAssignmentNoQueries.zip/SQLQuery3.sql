USE [AdventureWorksDW2012]
GO

/*****
1. Create an �Orders� table which comprises of these columns � �order_id�, �order_date�, �amount�,
�customer_id�
****/

/****** Object:  Table [dbo].[Orders]    Script Date: 10/18/2022 10:36:21 PM ******/
DROP TABLE [dbo].[Orders]
GO

/****** Object:  Table [dbo].[Orders]    Script Date: 10/18/2022 10:36:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Orders](
	[order_id] [int] IDENTITY(1,1) NOT NULL,
	[order_date] [date] NOT NULL,
	[amount] [money] NOT NULL,
	[customer_id] [int] NOT NULL
 CONSTRAINT [PK_Orders_order_id] PRIMARY KEY CLUSTERED 
(
	[order_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Orders_Customer] FOREIGN KEY([customer_id])
REFERENCES [dbo].[Customer] ([customer_id])
GO

ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Orders_Customer]
GO

INSERT INTO [dbo].[Orders]
           ([order_date]
           ,[amount]
           ,[customer_id])
     VALUES
           ('10-Oct-2022'
           ,1100
           ,1)
GO
INSERT INTO [dbo].[Orders]
           ([order_date]
           ,[amount]
           ,[customer_id])
     VALUES
           ('10-Oct-2022'
           ,1100
           ,2)
GO
INSERT INTO [dbo].[Orders]
           ([order_date]
           ,[amount]
           ,[customer_id])
     VALUES
           ('14-Oct-2022'
           ,1300
           ,4)
GO
INSERT INTO [dbo].[Orders]
           ([order_date]
           ,[amount]
           ,[customer_id])
     VALUES
           ('11-Oct-2022'
           ,150
           ,5)
GO
/*****
2. Make an inner join on �Customer� & �Order� tables on the �customer_id� column ****/

select * 
from Customer c inner join Orders o on c.customer_id = o.customer_id


/*****3. Make left and right joins on �Customer� & �Order� tables on the �customer_id� column ****/
select * 
from Customer c left join Orders o on c.customer_id = o.customer_id

select * 
from Customer c right join Orders o on c.customer_id = o.customer_id

/*****4. Update the �Orders� table, set the amount to be 100 where �customer_id� is 5 ****/

UPDATE [dbo].[Orders]
   SET [amount] = 100
 WHERE customer_id = 5
GO

