USE [AdventureWorksDW2012]
GO

/******1. Create a customer table which comprises of these columns � �customer_id�, �first_name�,
�last_name�, �email�, �address�, �city�,�state�,�zip�
******/

/****** Object:  Table [dbo].[Customer]    Script Date: 10/18/2022 10:36:21 PM ******/
DROP TABLE [dbo].[Customer]
GO

/****** Object:  Table [dbo].[Customer]    Script Date: 10/18/2022 10:36:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Customer](
	[customer_id] [int] IDENTITY(1,1) NOT NULL,
	[first_name] [nvarchar](100) NULL,
	[last_name] [nvarchar](100) NULL,
	[email] [nvarchar](255) NULL,
	[address] [nvarchar](255) NULL,
	[city] [nvarchar](50) NULL,
	[state] [nvarchar](50) NULL,
	[zip] [nvarchar](50) NULL
 CONSTRAINT [PK_Customer_customer_id] PRIMARY KEY CLUSTERED 
(
	[customer_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
) ON [PRIMARY]

GO

/******2. Insert 5 new records into the table******/
USE [AdventureWorksDW2012]
GO

INSERT INTO [dbo].[Customer]
           ([first_name]
           ,[last_name]
           ,[email]
           ,[address]
           ,[city]
           ,[state]
           ,[zip])
     VALUES
           ('Sammy'
           ,'Doel'
           ,'sammy.doel@gmail.com'
           ,'Wherever Street name 01'
           ,'City 01'
           ,'State 01'
           ,'Zip 01')
GO
INSERT INTO [dbo].[Customer]
           ([first_name]
           ,[last_name]
           ,[email]
           ,[address]
           ,[city]
           ,[state]
           ,[zip])
     VALUES
           ('Sunny'
           ,'Doel'
           ,'sunny.doel@gmail.com'
           ,'Wherever Street name 02'
           ,'City 02'
           ,'State 02'
           ,'Zip 02')
GO
INSERT INTO [dbo].[Customer]
           ([first_name]
           ,[last_name]
           ,[email]
           ,[address]
           ,[city]
           ,[state]
           ,[zip])
     VALUES
           ('Samad'
           ,'Doel'
           ,'samad.doel@gmail.com'
           ,'Wherever Street name 03'
           ,'City 03'
           ,'State 03'
           ,'Zip 03')
GO
INSERT INTO [dbo].[Customer]
           ([first_name]
           ,[last_name]
           ,[email]
           ,[address]
           ,[city]
           ,[state]
           ,[zip])
     VALUES
           ('Shakira'
           ,'Doel'
           ,'shakira.doel@gmail.com'
           ,'Wherever Street name 04'
           ,'City 04'
           ,'State 04'
           ,'Zip 04')
GO
INSERT INTO [dbo].[Customer]
           ([first_name]
           ,[last_name]
           ,[email]
           ,[address]
           ,[city]
           ,[state]
           ,[zip])
     VALUES
           ('Gabr'
           ,'Doel'
           ,'sabr.doel@gmail.com'
           ,'Wherever Street name 05'
           ,'San Jose'
           ,'State 05'
           ,'Zip 05')
GO


/******3. Select only the �first_name� & �last_name� columns from the customer table******/
select first_name, last_name
from Customer
go

--4. Select those records where �first_name� starts with �G� and city is �San Jose�******/
select * 
from Customer
where first_name like 'G%' and city = 'San Jose'
