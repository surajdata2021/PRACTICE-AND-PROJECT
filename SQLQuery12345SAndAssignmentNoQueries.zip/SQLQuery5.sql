


USE [AdventureWorksDW2012]
GO

/*** 1. Arrange the �Orders� dataset in decreasing order of amount ****/
SELECT [order_id]
      ,[order_date]
      ,[amount]
      ,[customer_id]
  FROM [dbo].[Orders]
order by amount desc
GO

/*** 2. Create a table with name �Employee_details1� and comprising of these columns � �Emp_id�,
�Emp_name�, �Emp_salary�. Create another table with name �Employee_details2�, which
comprises of same columns as first table.****/
/****** Object:  Table [dbo].[Employee_details1]    Script Date: 10/18/2022 10:36:21 PM ******/
DROP TABLE [dbo].[Employee_details1]
GO

/****** Object:  Table [dbo].[Employee_details1]    Script Date: 10/18/2022 10:36:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Employee_details1](
	[Emp_id] [int] IDENTITY(1,1) NOT NULL,
	[Emp_name] [nvarchar](200) NULL,
	[Emp_salary] [money] NOT NULL
 CONSTRAINT [PK_Employee_details1_Emp_id] PRIMARY KEY CLUSTERED 
(
	[Emp_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
) ON [PRIMARY]

GO


INSERT INTO [dbo].[Employee_details1]
           ([Emp_name]
           ,[Emp_salary])
     VALUES
           ('Sammy Doel'
           ,101)
GO

INSERT INTO [dbo].[Employee_details1]
           ([Emp_name]
           ,[Emp_salary])
     VALUES
           ('Sunny Doel'
           ,201)
GO

INSERT INTO [dbo].[Employee_details1]
           ([Emp_name]
           ,[Emp_salary])
     VALUES
           ('Samad Doel'
           ,301)
GO

/****** Object:  Table [dbo].[Employee_details2]    Script Date: 10/18/2022 10:36:21 PM ******/
DROP TABLE [dbo].[Employee_details2]
GO

CREATE TABLE Employee_details2 AS
	SELECT Emp_id
		  ,Emp_name
		  ,Emp_salary
	  FROM [dbo].[Employee_details1]
	  where 1=2
GO

INSERT INTO [dbo].[Employee_details2]
           ([Emp_name]
           ,[Emp_salary])
     VALUES
           ('Shakira Doel'
           ,401)
GO

INSERT INTO [dbo].[Employee_details2]
           ([Emp_name]
           ,[Emp_salary])
     VALUES
           ('Gabr Doel'
           ,501)
GO


--3. Apply the union operator on these two tables

select * from Employee_details1
UNION
select * from Employee_details2


--4. Apply the intersect operator on these two tables
select * from Employee_details1
INTERSECT
select * from Employee_details2

--5. Apply the except operator on these two tables
select * from Employee_details1
EXCEPT
select * from Employee_details2